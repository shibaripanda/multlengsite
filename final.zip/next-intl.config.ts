import { defaultLeng, lengList } from "./leng.config";

const config = {
    locales: lengList,
    defaultLocale: defaultLeng,
  };
  
  export default config;