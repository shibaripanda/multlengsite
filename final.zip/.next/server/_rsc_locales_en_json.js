"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "_rsc_locales_en_json";
exports.ids = ["_rsc_locales_en_json"];
exports.modules = {

/***/ "(rsc)/./locales/en.json":
/*!*************************!*\
  !*** ./locales/en.json ***!
  \*************************/
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"title":"App for service center","buttonTry":"Try without registration","buttonGetStarted":"Get started","back":"Back","free":"Completely free for the first year","ads":"Create orders, print documents, manage inventory, calculate income, add employees, set up access rights, integrate Telegram, use the desktop and mobile versions"}');

/***/ })

};
;