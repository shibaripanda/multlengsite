export const lengList: string[] = ['ru', 'en']
export const defaultLeng: string = 'en'