"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "_rsc_locales_ru_json";
exports.ids = ["_rsc_locales_ru_json"];
exports.modules = {

/***/ "(rsc)/./locales/ru.json":
/*!*************************!*\
  !*** ./locales/ru.json ***!
  \*************************/
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"title":"Приложение для сервисного центра","buttonTry":"Попробовать без регистрации","buttonGetStarted":"Начать","back":"Назад","free":"Совершенно бесплатно первый год","ads":"Создавай заказы, печатай документы, веди складской учет, считай доходы, добавляй сотрудников, настраивай права доступа, интегрируй телеграм, используй десктопную и мобильную версию"}');

/***/ })

};
;